/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef GESTURE_MANAGER_H
#define GESTURE_MANAGER_H

#include <map>

#include "utils/ParamsMap.h"
#include "utils/Factory.h"
#include "utils/Delegate.h"
#include "utils/RTTI.h"
#include "SelfLib.h"				// include last

//! Forward declare
class IGesture;

//! This manager manages all gestures available to the local self instance. Normally a SkillGesture
//! will invoke into this manager to execute various gestures to perform actions.
class SELF_API GestureManager : public ISerializable
{
public:
	RTTI_DECL();

	//! Types
	typedef std::list<std::string>	GestureFiles;
	typedef std::multimap< std::string, boost::shared_ptr<IGesture> >	GestureMap;
	typedef Factory< IGesture >		GestureFactory;
	typedef Delegate<IGesture *>	GestureDelegate;

	//! Construction
	GestureManager();
	~GestureManager();

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! Accessors
	const GestureMap & GetGestureMap() const
	{
		return m_GestureMap;
	}

	//! This finds all gestures who have the given ID and can be executed with the given params, returns false if none are found.
	bool FindGestures( const std::string & a_GestureId, const ParamsMap & a_Params, 
		std::vector< IGesture * > & a_Gestures ) const;

	//! Initialize and start this sensor manager.
	bool Start(const GestureFiles & a_Files );
	//! Stop this sensor manager.
	bool Stop();

private:
	//! Data
	bool					m_bActive;
	GestureMap				m_GestureMap;	
};

#endif
