/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef KNOWLEDGE_GRAPH_H
#define KNOWLEDGE_GRAPH_H

#include <boost/enable_shared_from_this.hpp>
#include <list>

#include "utils/ISerializable.h"
#include "utils/IDataStore.h"
#include "SelfLib.h"

//! This class wraps a persisted distributed knowledge graph that can be used to store nodes of information and the 
//! relationships between those nodes. This class relies on the TopicManager to distribute the data between 
//! all the self instances.
class SELF_API KnowledgeGraph : public ISerializable, boost::enable_shared_from_this<KnowledgeGraph>
{
public:
	RTTI_DECL();

	class Edge;

	//! This class defines a verticie in the knowledge graph. 
	class SELF_API Vert : public ISerializable, boost::enable_shared_from_this<Vert>
	{
	public:
		RTTI_DECL();

		//!Types
		typedef boost::shared_ptr<Vert>			SP;
		typedef boost::weak_ptr<Vert>			WP;
		typedef boost::shared_ptr<Edge>			EdgeSP;
		typedef std::list< EdgeSP >				EdgeList;

		//! Construction
		Vert( const IDataStore::KeyValueList & a_Records );
		Vert( const IDataStore::KeyValue::SP & a_spRecord );

		//! Accessors
		const std::string & GetUID() const;
		const IDataStore::KeyValueList & GetProperties() const;
		const EdgeList & GetEdges() const;

	private:
		//! Data
		std::string					m_UID;			// unique ID for this node
		IDataStore::KeyValueList	m_Records;
	};

	//! This object defines a relationship between two nodes in this graph, this is one direction.
	class SELF_API Edge : public ISerializable, boost::enable_shared_from_this<Edge>
	{
	public:
		RTTI_DECL();

		//!Types
		typedef boost::shared_ptr<Edge>			SP;
		typedef boost::weak_ptr<Edge>			WP;

		//! Construction
		Edge( const Vert::SP & a_Origin, const Vert::SP & a_Target, float a_fConfidence = 1.0f );

		//! Accessors
		float			GetConfidence() const;
		double			GetTimestamp() const;

	private:
		//! Data
		Vert::WP		m_spOrigin;		
		Vert::WP		m_spTarget;
		float			m_fConfidence;
	};


};

#endif // KNOWLEDGE_GRAPH_H
