/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_QUESTIONAGENT_H
#define SELF_QUESTIONAGENT_H

#include "IAgent.h"
#include "utils/Factory.h"
#include "blackboard/QuestionIntent.h"
#include "blackboard/Status.h"
#include "blackboard/Clarification.h"
#include "blackboard/Confirm.h"
#include "SelfLib.h"

class Dialog;
struct Dialogs;
struct ConverseResponse;
struct Classifiers;
struct Classifier;

class XRAY;
class NaturalLanguageClassifier;

class SELF_API QuestionAgent : public IAgent
{
public:
	RTTI_DECL();

	//! Construction
	QuestionAgent();

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);
	
	//! IAgent interface
	virtual bool OnStart();
	virtual bool OnStop();

	void OnHealth( const ThingEvent & a_Event );

private:
	//! Types
	class ProcessQuestion
	{
	public:
		ProcessQuestion(QuestionAgent * a_pAgent, QuestionIntent::SP a_spQuestion);
		~ProcessQuestion();

	private:
		//! Callbacks
		void OnDialog(const Json::Value & json);
		void OnAnswer(const Json::Value & json);
		void OnFinalResult();

		void OnClarification(Clarification::SP a_spClarification);
		void OnConfirm(Confirm::SP a_spConfirm);

		QuestionAgent *		m_pAgent;
		QuestionIntent::SP	m_spQuestion;
		Status::SP			m_spStatus;
		int					m_PendingRequests;
		int					m_CompletedRequests;
		bool				m_bGoalCreated;
		Json::Value			m_DialogResponse;
		Json::Value			m_AnswerResponse;
	};

	struct DialogInfo : public ISerializable
	{
		DialogInfo() : 
			m_AppendDialogClass(false),
			m_DialogUsesIntent(true),
			m_UpdateInterval( 60 * 7 ),
			m_Language("en"),
			m_pAgent( NULL ),
			m_ConversationId( 0 ), 
			m_ClientId( 0 ),
			m_bDialogStarted( false ),
			m_nUpdateOps( 0 ),
			m_bUploading(false)
		{}

		bool						m_AppendDialogClass;		// if true, the text will be classified by NLC then appended onto the text before sending to dialog
		bool						m_DialogUsesIntent;			// if true, then the question pipeline will be passed into the dialog instead of the actual text transcript
		double						m_UpdateInterval;			// how often to check for new dialogs/classifiers

		std::string					m_DialogId;					// the dialog ID to use
		std::string					m_DialogFile;

		std::string					m_ClassifierId;				// the NLC classifier to use
		std::string					m_ClassifierFile;
		std::string					m_Language;

		QuestionAgent *				m_pAgent;
		int							m_ConversationId;
		int							m_ClientId;

		bool                        m_bDialogStarted;
		TimerPool::ITimer::SP		m_spUpdateTimer;

		int							m_nUpdateOps;
		VoidDelegateList			m_OnUpdateList;
		bool						m_bUploading;

		//! Initialize this dialog and make it ready for conversation
		void Start( QuestionAgent * a_pAgent );
		void Update();

		//! Converse with this dialog, provide the end-result 
		void Converse( QuestionIntent::SP a_spQuestion, Delegate<const Json::Value &> a_Callback );

		void Serialize(Json::Value & json)
		{
			json["m_AppendDialogClass"] = m_AppendDialogClass;
			json["m_DialogUsesIntent"] = m_DialogUsesIntent;
			json["m_UpdateInterval"] = m_UpdateInterval;
			json["m_DialogId"] = m_DialogId;
			json["m_DialogFile"] = m_DialogFile;
			json["m_ClassifierId"] = m_ClassifierId;
			json["m_ClassifierFile"] = m_ClassifierFile;
			json["m_Language"] = m_Language;
		}
		void Deserialize(const Json::Value & json)
		{
			m_AppendDialogClass = json["m_AppendDialogClass"].asBool();
			m_DialogUsesIntent = json["m_DialogUsesIntent"].asBool();
			m_UpdateInterval = json["m_UpdateInterval"].asDouble();
			m_DialogId = json["m_DialogId"].asString();
			m_DialogFile = json["m_DialogFile"].asString();
			m_ClassifierId = json["m_ClassifierId"].asString();
			m_ClassifierFile = json["m_ClassifierFile"].asString();
			m_Language = json["m_Language"].asString();
		}

	private:
		void OnDialogStarted(const Json::Value & json);
		void OnGetDialogs(Dialogs * a_pDialogs);
		void OnDialogUploaded(const Json::Value & json);
		void OnDeleteDialog(const Json::Value & json);
		void OnGetClassifiers(Classifiers * a_pClassifiers);
		void OnTrainClassifier(Classifier * a_pClassifier);
		void OnDeleteClassifier(const Json::Value & json);
		void OnUpdated();
	};

	class DialogRequest
	{
	public:
		DialogRequest(DialogInfo * a_pDialogInfo, QuestionIntent::SP a_spQuestion,
			Delegate<const Json::Value &> a_Callback);

		void Execute();
		void OnClassify(const Json::Value & json);
		void OnDialog(const Json::Value & json);

	private:
		DialogInfo * m_pDialogInfo;
		QuestionIntent::SP m_spQuestion;
		Delegate<const Json::Value &> m_Callback;
		bool m_Retried;
	};

	//! Data
	Dialog *					m_pDialog;
	XRAY *						m_pXRAY;
	NaturalLanguageClassifier *	m_pNLC;

	// TODO: Add DeepQA service

	double						m_MinDialogConfidence;
	double						m_MinAnswerConfidence;
	double						m_UseDialogConfidence;		
	std::string					m_DialogMissIntent;
	float						m_HangOnTime;
	int							m_nQuestionLimit;		// maximum number of active questions 
	std::string					m_ClarificationTag;			// tag in a dialog response that if found will put a clarification object on the the blackboard.
	std::string					m_ConfirmationTag;			// tag in a dialog response for a confirmation

	std::vector<DialogInfo>		m_Dialogs;				// one or more dialogs to query
	std::vector<std::string>	m_HangOnResponses;
	std::vector<std::string>	m_PipelineDownResponses;

	TimerPool::ITimer::SP		m_spHangOnTimer;
	bool						m_IgnoreMissedDialogNodes;
	std::list<ProcessQuestion *> m_ActiveQuestions;

    void OnQuestionIntent(const ThingEvent & a_ThingEvent);
	void OnHangOnIntent(const ThingEvent & a_ThingEvent);
	void StopIgnoring();
};

#endif //SELF_QUESTIONAGENT_H
