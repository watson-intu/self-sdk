/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_EXCESSIVEPROCESSINGAGENT_H
#define SELF_EXCESSIVEPROCESSINGAGENT_H

#include "IAgent.h"
#include "blackboard/IThing.h"
#include "utils/Factory.h"
#include "utils/TimerPool.h"
#include "sensors/IData.h"

#include "SelfLib.h"

//! Forward Declarations
class SelfInstance;
class Goal;

class SELF_API ExcessiveProcessingAgent : public IAgent
{
public:
    RTTI_DECL();

	ExcessiveProcessingAgent() : m_fProcessingTime( 2.0f )
	{
		m_PleaseWaitText.push_back( "ummmm...." );
	}

	//! ISerialize interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

    //! IAgent interface
	virtual bool OnStart();
	virtual bool OnStop();

private:
	//! Types
	struct ProcessingIThing
	{
		ProcessingIThing(ExcessiveProcessingAgent * a_pAgent, IThing::SP a_spThing);
		ProcessingIThing(const ProcessingIThing & a_Copy);
		~ProcessingIThing();

		void OnTimer();

		ExcessiveProcessingAgent *
							m_pAgent;
		IThing::SP          m_spThing;
		TimerPool::ITimer::SP
							m_spTimer;
	};
	typedef std::list< ProcessingIThing > ProcessingThingList;

	//! Data
	float					m_fProcessingTime;
	std::vector<std::string>
							m_PleaseWaitText;

    TimerPool *             m_pTimerPool;
    ProcessingThingList     m_ProcessingThingList;

    //! Callbacks
    virtual void OnThingEvent(const ThingEvent & a_ThingEvent);
};

#endif //SELF_EXCESSIVEPROCESSINGAGENT_H