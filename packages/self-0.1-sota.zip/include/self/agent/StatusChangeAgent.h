/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_STATUSCHANGEAGENT_H
#define SELF_STATUSCHANGEAGENT_H

#include "IAgent.h"
#include "utils/Factory.h"
#include "sensors/IData.h"

#include "SelfLib.h"


//! Forward Declarations
class SelfInstance;
class Goal;

class SELF_API StatusChangeAgent : public IAgent
{
public:
    RTTI_DECL();

    //! IAgent interface
	virtual bool OnStart();
	virtual bool OnStop();

private:
    //! Callbacks
    virtual void RegisterIntent(const ThingEvent & a_ThingEvent);
};

#endif //SELF_STATUSCHANGEAGENT_H
