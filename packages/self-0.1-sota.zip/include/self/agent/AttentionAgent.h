/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_ATTENTIONAGENT_H
#define SELF_ATTENTIONAGENT_H

#include "IAgent.h"
#include "blackboard/Proximity.h"
#include "blackboard/Person.h"
#include "blackboard/HangOnIntent.h"
#include "utils/Factory.h"
#include "utils/TimerPool.h"
#include "sensors/SensorManager.h"
#include "sensors/GazeData.h"
#include "classifiers/ClassifierManager.h"
#include "classifiers/TextClassifier.h"
#include "classifiers/filters/NonsenseFilter.h"
#include "blackboard/HangOnIntent.h"

#include "SelfLib.h"

  
class SELF_API AttentionAgent : public IAgent
{ 
 public:
	RTTI_DECL();
	
AttentionAgent() : m_GazeDetected(false), m_HoldingOn(false), m_InProximity(false), m_ElevatedThresh(0.0f), m_StandardThresh(0.0f),
                   m_LoweredThresh(0.0f), m_TimeHoldOn( 0.0f ), m_TimeProximityWait( 0.0f ), m_TimeGazeWait( 0.0f )
		{}
	
	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);
	
	//! IAgent interface
	virtual bool OnStart();
	virtual bool OnStop();

 private:
	//! Types
	typedef SensorManager::SensorList SensorList;

	//! Data
	bool            m_GazeDetected;
	bool            m_HoldingOn;
	bool            m_InProximity;
	float           m_ElevatedThresh;
	float           m_LoweredThresh;
	float           m_StandardThresh;
	float			m_TimeHoldOn;
	float           m_TimeProximityWait;
	float           m_TimeGazeWait;

	SensorList      m_GazeSensors;
	
	TimerPool::ITimer::SP       m_spHoldOnWaitTimer;
	TimerPool::ITimer::SP       m_spProximityWaitTimer;
	TimerPool::ITimer::SP       m_spGazeWaitTimer;
	
	void		OnGaze(IData * data);
	void		OnHoldOn(const ThingEvent & a_ThingEvent);
	void        OnHoldOff();
	void		OnProximity(const ThingEvent & a_ThingEvent);
	void        OnProximityCheck();
	void        OnGazeCheck();

};

#endif //SELF_ATTENTIONAGENT
