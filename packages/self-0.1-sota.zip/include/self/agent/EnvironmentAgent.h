/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_ENVIRONMENTANOMALYAGENT_H
#define SELF_ENVIRONMENTANOMALYAGENT_H

#include "IAgent.h"
#include "SelfLib.h"

class SELF_API EnvironmentAgent : public IAgent
{
public:
    RTTI_DECL();

    EnvironmentAgent()
    {}

    //! ISerializable interface
    void Serialize( Json::Value & json );
    void Deserialize( const Json::Value & json );

    //! IAgent interface
	virtual bool OnStart();
	virtual bool OnStop();

private:
    //! Event Handlers
    void                    OnAnomaly(const ThingEvent & a_ThingEvent);
    void                    OnPerson(const ThingEvent & a_ThingEvent);
    void                    OnMessageReceived(const std::string & a_Message);
    void                    OnEnableTextMessage();
};

#endif //SELF_ENVIRONMENTAGENT_H
