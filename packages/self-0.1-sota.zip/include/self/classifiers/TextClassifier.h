/**
* Copyright 2016 IBM Corp. All Rights Reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* Limitations under the License.
*
*/

#ifndef SELF_TEXT_CLASSIFIER_H
#define SELF_TEXT_CLASSIFIER_H

#include <list>

#include "IClassifier.h"
#include "blackboard/Text.h"
#include "blackboard/Clarification.h"
#include "SelfLib.h"

//! Define to non-zero to enable nonsense classification support
#define ENABLE_NONSENSE_CLASS		1

// forward declare
struct Classifier;
struct Classifiers;
class NaturalLanguageClassifier;

//! This classifier subscribes to all audio sensors, converts any speech to text, then classifies
//! that speech into a Concept object that is added to the Blackboard.
class SELF_API TextClassifier : public IClassifier
{
public:
	RTTI_DECL();

	//! Interface class for filtering NLC results before we generate an intent. 
	class SELF_API IClassFilter : public ISerializable,
		public boost::enable_shared_from_this<IClassFilter>
	{
	public:
		RTTI_DECL();

		//! Types
		typedef boost::shared_ptr<IClassFilter>		SP;
		typedef boost::weak_ptr<IClassFilter>		WP;
		//! Interface
		virtual bool ApplyFilter(Json::Value & a_Intent, Json::Value & a_Parse) = 0;		// return true if classification should be ignored
	};
	typedef std::vector<IClassFilter::SP>		Filters;

	template<typename T>
	boost::shared_ptr<T> FindFilter() const
	{
		for (size_t i = 0; i < m_Filters.size(); ++i)
		{
			boost::shared_ptr<T> spFilter = DynamicCast<T>( m_Filters[i] );
			if (spFilter)
				return spFilter;
		}
		return boost::shared_ptr<T>();
	}

	//! Construction
	TextClassifier();
	~TextClassifier();

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! IClassifier interface
	virtual const char * GetName() const;
	virtual bool OnStart();
	virtual bool OnStop();	

	const std::string & GetClassifierId() const
	{
		return m_ClassifierId;
	}
	
	//! Mutators
	void SetMinIntentConfidence(double a_Val);
	void SetHoldOnState(bool a_State);

	//! queue data to train our classifier with a new phrase and class.
	bool RetrainClassifier(const std::string & a_Text,
		const std::string & a_Class);

	// to get the min intent threshold value
	const double GetMinIntentConfidence();

private:
	//! Callback handler
	void OnText(const ThingEvent & a_ThingEvent);
	void CheckClassifiers();
	void OnGetClassifiers (Classifiers * a_pClassifiers );
	void OnGetClassifier( Classifier * a_pClassifier );
	void TrainClassifier();
	void OnClassifierDeleted(const Json::Value & json);
	void OnClassifierTrained( Classifier * a_pClassifer );
	void OnHealth(const ThingEvent & a_Event);
	void OnClarification(const ThingEvent & a_Event );

	//! Types
	class ClassifyText
	{
	public:
		ClassifyText(TextClassifier * a_pClassifier, Text::SP a_spSpeech);

	private:
		void OnTextClassified(const Json::Value & json);
		void OnTextParsed(const Json::Value & json);
		void OnClassifyDone();

		TextClassifier *	m_pClassifier;
		Text::SP			m_spText;
		Json::Value			m_Intent;
		Json::Value			m_Parse;
		int					m_PendingReq;
		int					m_CompletedReq;
		bool				m_bError;

	};

	// map a NLC intent to a given IIntent derived class.
	struct IntentClass : public ISerializable
	{
		RTTI_DECL();

		IntentClass()
		{}
		IntentClass(const std::string & a_Intent, const std::string & a_Class) :
			m_Intent(a_Intent), m_Class(a_Class)
		{}

		std::string			m_Intent;
		std::string			m_Class;

		virtual void Serialize(Json::Value & json)
		{
			json["m_Intent"] = m_Intent;
			json["m_Class"] = m_Class;
		}
		virtual void Deserialize(const Json::Value & json)
		{
			m_Intent = json["m_Intent"].asString();
			m_Class = json["m_Class"].asString();
		}
	};
	typedef std::vector<IntentClass>		IntentClasses;

	//! Data
	NaturalLanguageClassifier *	m_pNLC;
	double			m_MinIntentConfidence;			// minimum confidence to create an intent
	IntentClasses	m_IntentClasses;				// maps an intent class to the correct intent class
	double			m_MinMissNodeConfidence;		// minimum confidence to post a dialog_miss_node
	std::string		m_ClassifierFile;				// training file to upload/update
	std::string		m_ClassifierId;					// intent classifier to use
	std::string		m_Language;						// language of our classifier (e.g. en)
	std::vector<std::string>
					m_FailureResponses;				// failure responses
	std::vector<std::string>
					m_LowConfidenceResponses;       // low confidence responses

	Filters			m_Filters;						// list of filters to apply to incoming classifications
	bool			m_bCheckedClassifiers;			// true once we've checked our classifiers
	bool  			m_bHoldOn;

	TimerPool::ITimer::SP
					m_spClassifiersTimer;			// timer use to check our classifiers
	Clarification::SP
					m_spClarification;				// active clarification

	double          m_LastFailureResponse;
	double          m_MinFailureResponseInterval;

	const std::string & GetFailureResponse();
	const std::string & GetLowConfidenceResponse();

};

#endif // SELF_TEXT_CLASSIFIER_H
