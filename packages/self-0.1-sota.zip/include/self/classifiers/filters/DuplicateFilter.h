/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_DUPLICATE_FILTER_H
#define SELF_DUPLICATE_FILTER_H

#include "classifiers/TextClassifier.h"
#include "SelfLib.h"

//! This classifier subscribes to all audio sensors, converts any speech to text, then classifies
//! that speech into a Concept object that is added to the Blackboard.
class SELF_API DuplicateFilter : public TextClassifier::IClassFilter
{
public:
	RTTI_DECL();

	DuplicateFilter();

	//! ISerialiable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);
	//! IClassFilter interface
	virtual bool ApplyFilter(Json::Value & a_Intent, Json::Value & a_Parse);

private:
	//! Data
	double			m_MinIntentWindow;				// min time between the same intent, this is a window to prevent duplicate from multiple inputs
	double			m_LastIntentTime;
	std::string		m_LastIntent;
};

#endif // SELF_DUPLICATE_FILTER_H
