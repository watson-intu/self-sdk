/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_TEXT_EXTRACTOR_H
#define SELF_TEXT_EXTRACTOR_H

#include <list>
#include <deque>

#include "IFeatureExtractor.h"
#include "blackboard/ThingEvent.h"
#include "sensors/SensorManager.h"
#include "services/SpeechToText/SpeechToText.h"
#include "utils/Factory.h"

#include "SelfLib.h"

class SelfInstance;

class SELF_API TextExtractor : public IFeatureExtractor
{
public:
	RTTI_DECL();

	//! Construction
	TextExtractor();

	//! ISerialziable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

    //! IFeatureExtractor interface
    virtual const char * GetName() const;
    virtual bool OnStart();
    virtual bool OnStop();

private:
    //! Types
    typedef SensorManager::SensorList	SensorList;

    //! Data
	float				m_MinConfidence;
	float 				m_MaxConfidence;
	float 				m_ConfidenceThreshold;
	float 				m_ConfidenceThresholdLocal;
	float				m_MinSpeechLevel;
	float 				m_StdDevThreshold;
	float 				m_EnergyTimeInterval;
	float 				m_MinEnergyAvg;
	float				m_MaxEnergyAvg;
	float 				m_NormalizedEnergyLevel; //Between 0 and 1
	double				m_MinFailureResponseInterval;
	int					m_EnergyAverageSampleCount;
	int 				m_MaxFailureResponsesCount;
	int 				m_BurnInCycles;
	int 				m_FailureResponsesCount;
	double 				m_EnergyLevelCrossedTimestamp;
	std::vector<std::string>
						m_FailureResponses;
	std::deque<float>	m_EnergyLevelAverages;

	double				m_LastFailureResponse;
	SensorList			m_AudioSensors;
    SensorList     		m_TextSensors;
	SpeechToText *		m_pSpeechToText;
	bool 				m_Listening;

    //! Callback handler
    void OnAudioData(IData * data);
    void OnTextData(IData * data);
	void OnHealth( const ThingEvent & a_Event );
    void OnRecognizeSpeech(RecognizeResults * a_pResults);
	void OnHighConfidence(const IThing::SP & a_Thing);
};

#endif //SELF_TEXT_EXTRACTOR_H
