/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


#ifndef SELF_SAY_H
#define SELF_SAY_H

#include "IThing.h"

//! This object is placed on the blackboard when we need self to say anything
class SELF_API Say : public IThing
{
public:
	RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<Say>			SP;
	typedef boost::weak_ptr<Say>			WP;

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! Construction
	Say() 
	{}
	Say( const std::string & a_Text, const std::string & a_VoiceOverride = "" ) :
		m_Text( a_Text ), m_VoiceOverride( a_VoiceOverride )
	{}

	//! Accessors
	const std::string & GetText() const 
	{
		return m_Text;
	}
	const std::string & GetVoiceOverride() const
	{
		return m_VoiceOverride;
	}

	void SetText( const std::string & a_Text )
	{
		m_Text = a_Text;
	}
	void SetVoiceOverride( const std::string & a_Voice )
	{
		m_VoiceOverride = a_Voice;
	}

private:
	//! Data
	std::string m_Text;
	std::string m_VoiceOverride;
};

#endif //SELF_IMAGE_H
