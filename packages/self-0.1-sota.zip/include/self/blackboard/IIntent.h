/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_IINTENT_H
#define SELF_IINTENT_H

#include "blackboard/IThing.h"
#include "utils/RTTI.h"

class SELF_API IIntent : public IThing
{
public:
    RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<IIntent>		SP;
	typedef boost::weak_ptr<IIntent>		WP;

    //! Construction
    virtual ~IIntent()
    {}

	virtual void Create(const Json::Value & a_Intent, const Json::Value & a_Parse) = 0;
};

#endif //SELF_IINTENT_H
