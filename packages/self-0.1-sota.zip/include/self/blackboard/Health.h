/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


#ifndef SELF_HEALTH_H
#define SELF_HEALTH_H

#include "IThing.h"

class SELF_API Health : public IThing
{
public:
    RTTI_DECL();

    //! Types
    typedef boost::shared_ptr<Health>       SP;
    typedef boost::weak_ptr<Health>         WP;

    //! ISerializable interface
    virtual void Serialize(Json::Value & json);
    virtual void Deserialize(const Json::Value & json);

    //! Construction
    Health() :
            IThing( 30.0f ), m_bError( false ), m_fHealthValue( 0.0f )
    {}

	Health(const std::string & a_HealthName, const std::string & a_HealthState, const float a_fHealthValue, bool a_bError ) :
			IThing( a_HealthState, 30.0f ), m_HealthName( a_HealthName ), m_fHealthValue( a_fHealthValue ), m_bError( a_bError )
	{}

	Health(const std::string & a_HealthName, bool a_bError) :
            IThing( a_bError ? "DOWN" : "UP", 30.0f ), m_HealthName( a_HealthName ), m_bError( a_bError ), m_fHealthValue( 0.0f )
    {}

    //! Accessors
    const std::string & GetHealthName() const
    {
        return m_HealthName;
    }
	bool IsError() const
	{
		return m_bError;
	}
	float GetHealthValue() const
	{
		return m_fHealthValue;
	}

    void SetHealthName( const std::string & a_HealthName )
    {
        m_HealthName = a_HealthName;
    }

private:
    //! Data
    std::string     m_HealthName;
    bool            m_bError;
	float           m_fHealthValue; // e.g. temperature
};

#endif //SELF_HEALTH_H
