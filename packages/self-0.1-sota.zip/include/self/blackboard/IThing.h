/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_ITHING_H
#define SELF_ITHING_H

#include <string>
#include <vector>
#include <stdio.h>

#include "boost/enable_shared_from_this.hpp"
#include "boost/shared_ptr.hpp"

#include "utils/UniqueID.h"
#include "utils/Time.h"
#include "utils/ISerializable.h"
#include "utils/RTTI.h"
#include "utils/ParamsMap.h"
#include "utils/Delegate.h"
#include "utils/TimerPool.h"

#include "SelfLib.h"		// include last always

class BlackBoard;
class ThingEvent;

//! These enums are setup as bit flags so the subscribe can subscribe for specific events.
enum ThingEventType
{
	TE_ADDED		= 0x1,			// IThing has been added
	TE_REMOVED		= 0x2,			// IThing has been removed
	TE_STATE		= 0x4,			// state of IThing has changed.
	TE_IMPORTANCE	= 0x8,			// Importance of IThing has changed.

	TE_ALL = TE_ADDED | TE_REMOVED | TE_STATE | TE_IMPORTANCE,
    TE_ADDED_OR_STATE = TE_ADDED | TE_STATE
};

//! This abstract interface is the base class for any object that can be added
//! to the blackboard. The idea is that things connect to each other automatically
//! using a trained graph, then drive the goals of the system. 
//! These things should automatically remove them-selves after they are no longer needed.

class SELF_API IThing : public ISerializable, public boost::enable_shared_from_this<IThing>
{
public:
	RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<IThing>	SP;
	typedef boost::weak_ptr<IThing>		WP;
	typedef std::vector< SP >			ThingList;

	//! Used by the FindThings() function.
	struct SearchCriteria
	{
		SearchCriteria( RTTI * a_pType, const std::string & a_ParentGuid) :
			m_pType( a_pType ), m_StartTime( -1.0), m_EndTime( -1.0 ), m_bRecursive( true ), m_ParentGuid( a_ParentGuid )
		{}
		SearchCriteria(RTTI * a_pType, double a_StartTime = -1.0, double a_EndTime = -1.0) :
			m_pType(a_pType), m_StartTime(a_StartTime), m_EndTime(a_EndTime), m_bRecursive(true), m_ParentGuid("")
		{}
		SearchCriteria( RTTI * a_pType, const char * a_State, double a_StartTime = -1.0, double a_EndTime = -1.0 ) :
			m_pType( a_pType ), m_State( a_State ), m_StartTime( a_StartTime ), m_EndTime( a_EndTime ), m_bRecursive( true ), m_ParentGuid( "" )
		{}
		SearchCriteria() : m_pType( NULL ), m_StartTime( -1.0 ), m_EndTime( -1.0 ), m_bRecursive( true ), m_ParentGuid( "" )
		{}

		RTTI * 				m_pType;			// If not NULL, then the thing should be of this type of object.
		std::string 		m_State;			// If not empty, then state should be == to this value
		double 				m_StartTime;		// If > 0.0, then thing create time should be >= this value
		double 				m_EndTime;			// If > 0.0, then thing create time should be <= this value
		const std::string	m_ParentGuid;

		bool 				m_bRecursive;		// if true, then the FindThing() will recurse the heirarchy of objects

		bool IsMatch( IThing * a_pThing ) const
		{
			if ( a_pThing == NULL )
				return false;
			if ( m_pType != NULL && !a_pThing->GetRTTI().IsType( m_pType ) )
				return false;
			if ( m_State[0] != 0 && a_pThing->GetState() != m_State )
				return false;
			if ( m_StartTime > 0.0 && a_pThing->GetCreateTime() < m_StartTime )
				return false;
			if ( m_EndTime > 0.0 && a_pThing->GetCreateTime() > m_EndTime )
				return false;
			if( m_ParentGuid[0] != 0 && a_pThing->GetGUID() != m_ParentGuid)
				return false;

			return true;
		}
	};

	//! Construction
	IThing( float a_LifeSpan = 3600.0f ) : 
		m_pBlackBoard( NULL ), 
		m_fImportance( 1.0f ),
		m_GUID( UniqueID().Get() ),
		m_fLifeSpan(a_LifeSpan)
	{}
    IThing( const std::string & a_State, float a_LifeSpan = 3600.0f ) :
            m_pBlackBoard( NULL ),
            m_fImportance( 1.0f ),
            m_GUID( UniqueID().Get() ),
            m_fLifeSpan(a_LifeSpan),
            m_State(a_State)
    {}
	virtual ~IThing()
	{}

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! Get our owning blackboard object.
	BlackBoard * GetBlackBoard() const
	{
		return m_pBlackBoard;
	}

	//! Get the unique ID for this object.
	const std::string & GetGUID() const
	{
		return m_GUID;
	}
	//! Get the creation time for this thing
	double GetCreateTime() const
	{
		return m_CreateTime.GetEpochTime();
	}
	//! Age of this thing in seconds
	double GetAge() const
	{
		return Time().GetEpochTime() - m_CreateTime.GetEpochTime();
	}

	//! The importance of this thing
	float GetImportance() const
	{
		return m_fImportance;
	}

	const std::string & GetState() const
	{
		return m_State;
	}

	//! Returns our parent object.
	SP GetParent() const
	{
		return m_pParent.lock();
	}

	//! Other things this thing is related too
	const ThingList & GetChildren() const
	{
		return m_Children;
	}

	//! Search children of this object, this doesn't check the current object.
	bool FindThings( ThingList & a_Found, const SearchCriteria & a_Find ) const
	{
		for(size_t i=0;i<m_Children.size();++i)
		{
			IThing * pChild = m_Children[i].get();
			if ( a_Find.IsMatch( pChild ) )
				a_Found.push_back( pChild->shared_from_this() );
			// if set for recursive, descend into the child object..
			if ( a_Find.m_bRecursive )
				pChild->FindThings( a_Found, a_Find );
		}
		
		return a_Found.size() > 0;
	}

	//! This finds a parent object of the given type.
	template<typename T>
	boost::shared_ptr<T> FindParentType() const 
	{
		SP spParent = GetParent();
		while (spParent)
		{
			boost::shared_ptr<T> spCasted = DynamicCast<T>(spParent);
			if (spCasted)
				return spCasted;

			spParent = spParent->GetParent();
		}

		return boost::shared_ptr<T>();
	}

	//! Mutators
	void SetBlackBoard(BlackBoard * a_pBlackBoard);

	void SetGUID(const std::string & a_GUID)
	{
		m_GUID = a_GUID;
	}

	void SetImportance(float a_fImportance)
	{
		if ( a_fImportance != m_fImportance )
		{
			m_fImportance = a_fImportance;
			OnImportanceChanged();
		}
	}

	void SetState( const std::string & a_NewState )
	{
		if ( m_State != a_NewState )
		{
			m_State = a_NewState;
			OnStateChanged();
		}
	}

	void AddChild(SP a_spThing);
	bool RemoveChild(size_t index);
	bool RemoveChild(IThing * a_pThing);
	void RemoveAllChildren();
	bool RemoveThis();

	//! subscribe to this specific instance for notifications.
	void Subscribe(Delegate<const ThingEvent &> a_Subscriber);
	bool Unsubscribe(void * a_pObject);

	//! Sends the given event to all subscribers and the owning blackboard.
	void SendEvent(const ThingEvent & a_Event);

	//! Interface
	virtual void OnAttached();				// this is invoked AFTER we have been attached into the hierarchy
	virtual void OnDetach();				// this is invoked BEOFRE we are detached from the hierarchy.
	virtual void OnImportanceChanged();		// invoked when the importance is changed
	virtual void OnStateChanged();			// invoked when the state is changed
	virtual void OnLifeSpanExpired();		// invoked by the timer when the lifespan of this thing is up

	//! Helpers

	//! Sort the things by time, ascending order places the newest thing last in the last.
	static void SortChron( ThingList & a_Things, bool a_bAcending = true );
	//! Returns a text description of the event type.
	static const char * ThingEventTypeText( ThingEventType a_eType );

protected:

	//! Types
	typedef Delegate<const ThingEvent &>	Subscriber;
	typedef std::list< Subscriber >			SubscriberList;

	//! Data
	BlackBoard *		m_pBlackBoard;		// blackboard containing this thing

	std::string			m_GUID;				// global unique ID for this thing
	Time				m_CreateTime;		// when was this thing made in seconds since epoch
	float				m_fImportance;		// how important is this thing
	std::string			m_State;			// state of this object
	WP					m_pParent;			// our parent thing
	ThingList			m_Children;			// things created from this thing

	float				m_fLifeSpan;
	TimerPool::ITimer::SP
						m_spDetachTimer;		// timer that will remove this object after it's life is over
	SubscriberList		m_Subscribers;		// subscribers for this instance
};


class ThingEvent
{
public:
	ThingEvent(IThing::SP a_pThing, ThingEventType a_Event) : m_spThing(a_pThing), m_Event(a_Event)
	{}
	ThingEvent() : m_Event(TE_ADDED)
	{}

	ThingEventType GetThingEventType() const
	{
		return m_Event;
	}

	IThing::SP GetIThing() const
	{
		return m_spThing;
	}

private:
	IThing::SP		m_spThing;
	ThingEventType 	m_Event;
};

#endif
