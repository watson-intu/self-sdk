/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_LEARNINGINTENT_H
#define SELF_LEARNINGINTENT_H

#include "IIntent.h"

class SELF_API LearningIntent : public IIntent
{
public:
    RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<LearningIntent>		SP;
	typedef boost::weak_ptr<LearningIntent>			WP;

	LearningIntent();

    //! ISerializable interface
    virtual void Serialize(Json::Value & json);
    virtual void Deserialize(const Json::Value & json);

	//! IIntent interface
	virtual void Create(const Json::Value & a_Intent, const Json::Value & a_Parse);

	//! Accessors and Mutators
	const std::string & GetText() const
	{
        return m_Text;
    }

	const Json::Value & GetTextParse() const 
	{
		return m_TextParse;
	}

	const std::string & GetTarget() const
	{
        return m_Target;
    }

	const std::string & GetVerb() const
	{
        return m_Verb;
    }

private:
	//! Types
	enum ParseContextFlags
	{
		P_THAT			= 0x1,
		P_HOW			= 0x2,
		P_IS			= 0x4,
		P_FORGET		= 0x8,
		P_TO			= 0x10,
		P_YOU			= 0x20
	};

    //! Data
    std::string m_Text;
	Json::Value m_TextParse;
    std::string m_Target;
    std::string m_Verb;

	void ParseLearn(const Json::Value & a_What, unsigned int & a_ParseContext );
	void ParseForget(const Json::Value & a_What, unsigned int & a_ParseContext );
	void ParseSchedule(const Json::Value & a_Parse, const Json::Value & a_What );
};

#endif //SELF_LEARNINGINTENT_H
