/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_TEXT_H
#define SELF_TEXT_H

#include "IThing.h"
#include "utils/StringUtil.h"

//! Recognized speech or entered text, usually attached to a person object if they are known. This object
//! will send the get processed by the TextClassifier object and a intent object will be attached to it on the 
//! blackboard.
class SELF_API Text : public IThing
{
public:
	RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<Text>		SP;
	typedef boost::weak_ptr<Text>		WP;

	//! Construction
	Text() : m_LocalDialog( false ), m_ClassifyIntent( true )
	{}
	Text( const std::string & a_Speech, bool a_bLocalDialog, bool a_bClassifyIntent ) : 
		m_Text ( StringUtil::Trim(a_Speech) ),
		m_LocalDialog ( a_bLocalDialog ),
		m_ClassifyIntent( a_bClassifyIntent )
	{}

	const std::string & GetText() const
	{
		return m_Text;
	}
	bool IsLocalDialog() const
	{
		return m_LocalDialog;
	}
	bool ClassifyIntent() const 
	{
		return m_ClassifyIntent;
	}

	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

private:
	//! Data
	std::string m_Text;
	bool 		m_LocalDialog;
	bool		m_ClassifyIntent;
};

#endif
