/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


#ifndef SELF_CLARIFICATION_H
#define SELF_CLARIFICATION_H

#include "IThing.h"

//! This object is placed on the blackboard when we need self to confirm an action
//! before we act. The FeedbackAgent will handle the positive/negative feedback that
//! will trigger the confirm or cancel responses of this object. 
class SELF_API Clarification : public IThing
{
public:
	RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<Clarification>	SP;
	typedef boost::weak_ptr<Clarification>		WP;
	typedef Delegate<SP>						ClarificationCallback;

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! Construction
	Clarification()
	{}
	Clarification( const Json::Value & a_Info, ClarificationCallback a_Callback ) :
		m_Info( a_Info ),
		m_Callback(a_Callback)
	{}

	const Json::Value & GetInfo() const
	{
		return m_Info;
	}
	const std::string & GetText() const
	{
		return m_Text;
	}

	void OnClarify( const std::string & a_Text );

private:
	//! Data
	std::string m_Text;
	Json::Value m_Info;
	ClarificationCallback m_Callback;
};

#endif //SELF_CLARIFICATION_H
