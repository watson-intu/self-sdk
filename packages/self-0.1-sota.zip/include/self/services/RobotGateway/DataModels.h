/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef ROBOT_GATEWAY_MODELS_H
#define ROBOT_GATEWAY_MODELS_H

#include "utils/ISerializable.h"
#include "SelfLib.h"

struct CustomData : public ISerializable
{
	RTTI_DECL();

	std::string		m_Keys;
	std::string		m_FieldName;
	std::string		m_Value;

	virtual void Serialize(Json::Value & json)
	{
		json["keys"] = m_Keys;
		json["fieldname"] = m_FieldName;
		json["value"] = m_Value;
	}

	virtual void Deserialize(const Json::Value & json) 
	{
		m_Keys = json["keys"].asString();
		m_FieldName = json["fieldname"].asString();
		m_Value = json["value"].asString();
	}
};

struct ServiceDetails : public ISerializable
{
	RTTI_DECL();

	std::string		m_Endpoint;
	std::string		m_User;
	std::string		m_Password;
	std::string		m_API;
	bool			m_Reachable;

	std::vector<CustomData>
					m_Custom;

	virtual void Serialize(Json::Value & json) {
		json["serviceEndpoint"] = m_Endpoint;
		json["userId"] = m_User;
		json["servicePass"] = m_Password;
		json["serviceApi"] = m_API;
		json["reachable"] = m_Reachable;

		SerializeVector("custom", m_Custom, json);
	}
	
	virtual void Deserialize(const Json::Value & json) 
	{
		m_Endpoint = json["serviceEndpoint"].asString();
		m_User = json["userId"].asString();
		m_Password = json["servicePass"].asString();
		m_API = json["serviceApi"].asString();
		m_Reachable = json["reachable"].asBool();

		DeserializeVector( "custom", json, m_Custom );
	}
};

struct Service : public ISerializable
{
	RTTI_DECL();

	std::string		m_Service;
	bool			m_Beta;
	ServiceDetails	m_Details;

	//!ISerizliable interface
	virtual void Serialize(Json::Value & json)
	{
		json["service"] = m_Service;
		json["beta"] = m_Beta;
		json["details"] = ISerializable::SerializeObject( &m_Details, false );
	}

	virtual void Deserialize(const Json::Value & json) 
	{
		m_Service = json["service"].asString();
		m_Beta = json["beta"].asBool();
		ISerializable::DeserializeObject( json["details"], &m_Details );
	}
};

struct ServiceList : public ISerializable
{
	RTTI_DECL();

	std::vector<Service> m_Services;

	virtual void Serialize(Json::Value & json)
	{
		SerializeVector( "services", m_Services, json );
	}

	virtual void Deserialize(const Json::Value & json) 
	{
		DeserializeVector( "services", json, m_Services );
	}
};


#endif //ROBOT_GATEWAY_MODELS_H
