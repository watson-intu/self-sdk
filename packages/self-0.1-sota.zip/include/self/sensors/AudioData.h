/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef AUDIO_DATA_H
#define AUDIO_DATA_H

#include "IData.h"
#include "sensors/ISensor.h"
#include "utils/Sound.h"
#include "SelfLib.h"

//! This data type contains raw wave audio data..
class SELF_API AudioData : public IData
{
public:
	RTTI_DECL();

	//! IData interface
	virtual bool ToBinary( std::string & a_Output )
	{
		return Sound::SaveWave( a_Output, m_Freq, m_Channels, m_BPS, m_WaveData );
	}

	AudioData(const std::string & a_WaveData, unsigned int a_Freq, unsigned int a_Channels, unsigned int a_BPS, ISensor * a_pOrigin ) :
		m_WaveData( a_WaveData ), m_Freq( a_Freq ), m_Channels( a_Channels ), m_BPS( a_BPS ), m_pOrigin( a_pOrigin )
	{}

	const std::string & GetWaveData() const
	{
		return m_WaveData;
	}

	unsigned int GetFrequency() const
	{
		return m_Freq;
	}
	unsigned int GetChannels() const
	{
		return m_Channels;
	}
	unsigned int GetBPS() const
	{
		return m_BPS;
	}
	ISensor * GetOrigin() const
	{
		return m_pOrigin;
	}

private:
	//! Data
	std::string			m_WaveData;
	unsigned int		m_Freq;
	unsigned int		m_Channels;
	unsigned int		m_BPS;		// bits per sample
	ISensor *			m_pOrigin;
};

#endif
