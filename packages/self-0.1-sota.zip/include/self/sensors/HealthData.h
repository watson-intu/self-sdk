/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef HEALTH_DATA_H
#define HEALTH_DATA_H

#include "IData.h"
#include "SelfLib.h"

class SELF_API HealthData : public IData
{
public:
    RTTI_DECL();

    HealthData(const std::string & a_HealthName, const std::string & a_HealthState, const bool a_bError) :
            m_HealthName( a_HealthName ), m_HealthState( a_HealthState ), m_bError( a_bError ), m_fHealthValue( 0.0f )
    {}

	HealthData(const std::string & a_HealthName, const std::string & a_HealthState, const float a_fHealthValue, const bool a_bError) :
			m_HealthName( a_HealthName ), m_HealthState( a_HealthState ), m_fHealthValue( a_fHealthValue ), m_bError( a_bError )
	{}

    HealthData(const std::string & a_HealthName, const bool a_bError) :
            m_HealthName( a_HealthName ), m_bError( a_bError ), m_fHealthValue( 0.0f ), m_HealthState(a_bError ? "DOWN" : "UP")
    {}

    ~HealthData()
    {}

    //!Accessors
    const std::string & GetHealthName() const
    {
        return m_HealthName;
    }

    const std::string & GetHealthState() const
    {
        return m_HealthState;
    }

	float GetHealthValue() const
	{
		return m_fHealthValue;
	}

    bool HasError() const
    {
        return m_bError;
    }

private:
    //!Data
    std::string     m_HealthName;  // name of service, joint, etc
    std::string     m_HealthState; // e.g. "UP", "DOWN"
    bool            m_bError;
	float           m_fHealthValue; // e.g. temperature
};


#endif //HealthData
