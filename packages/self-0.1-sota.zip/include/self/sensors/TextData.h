/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_TEXT_DATA_H
#define SELF_TEXT_DATA_H

#include "IData.h"
#include "SelfLib.h"

//! This object wraps a simple string in the IData interface. This carries input from keyboards or local STT devices.
class SELF_API TextData : public IData 
{
public:
	RTTI_DECL();

	TextData(const std::string & a_Text, float a_fConfidence) 
		: m_Text( a_Text ), m_fConfidence( a_fConfidence )
	{}

	~TextData()
	{}

	//!Accessors
	const std::string & GetText() const
	{
		return m_Text;
	}
	float GetConfidence() const
	{
		return m_fConfidence;
	}
private:
	//!Data
	std::string  	m_Text;
	float			m_fConfidence;
};


#endif //TouchData
