/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_MOODDATA_H
#define SELF_MOODDATA_H

#include "SelfLib.h"

class SELF_API MoodData : public IData
{
public:
    RTTI_DECL();

    MoodData(bool a_IsSmiling)
            : m_IsSmiling(a_IsSmiling)
    {}

    ~MoodData()
    {}

    //!Accessors
    bool GetIsSmiling() const
    {
        return m_IsSmiling;
    }
private:
    //!Data
    bool			m_IsSmiling;
};

#endif //SELF_MOODDATA_H
