/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_REMOTEDEVICEDATA_H
#define SELF_REMOTEDEVICEDATA_H

#include "jsoncpp/json/json.h"

#include "IData.h"
#include "SelfLib.h"

//! This data type contains raw wave audio data..
class SELF_API RemoteDeviceData : public IData
{
public:
    RTTI_DECL();

    // For Environment Data
    RemoteDeviceData(const Json::Value & a_Content) : m_Content( a_Content )
    {}

    ~RemoteDeviceData()
    {}

    //!Accessors
    const Json::Value & GetContent() const
    {
        return m_Content;
    }

private:
    //!Data
    Json::Value  	    m_Content;
};

#endif
