/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef ISENSOR_H
#define ISENSOR_H

#include <string>
#include <map>
#include <stdio.h>

#include "boost/enable_shared_from_this.hpp"
#include "boost/shared_ptr.hpp"

#include "topics/ITopics.h"
#include "utils/ISerializable.h"
#include "utils/Delegate.h"
#include "utils/RTTI.h"
#include "utils/StringUtil.h"
#include "SensorManager.h"
#include "IData.h"
#include "SelfLib.h"

//! This is the base class for all sensors that can receive some type of input from an external 
//! source. Examples include connected video camera, microphone input, or data through a connected
//! socket.
class SELF_API ISensor : public ISerializable, public boost::enable_shared_from_this<ISensor>
{
public:
	RTTI_DECL();

	//! Types
	typedef boost::shared_ptr<ISensor>	SP;

	//! Construction
	ISensor() : m_pTopics( NULL ), m_TopicSubscribers( 0 )
	{}
	virtual ~ISensor()
	{}

	//! Accessors
	bool IsActive() const 
	{
		return m_Subscribers.size() > 0;
	}

	//! ISerializable interface
	virtual void Serialize(Json::Value & json) {}
	virtual void Deserialize(const Json::Value & json) {}

	//! Interface
	virtual const char * GetSensorName() = 0;
	virtual RTTI & GetSensorDataType() = 0;

	//! This is invoked when the first subscriber subscribes to this sensor
	virtual bool OnStart() = 0;
	//! This is invoked when the last subscriber un-subscribes.
	virtual bool OnStop() = 0;
	//! This is invoked to pause this sensor.
	virtual void OnPause() = 0;
	//! This is inovked to restart this sensor.
	virtual void OnResume() = 0;

	//! This is invoke by the SensorManager to register any topics provided by this sensor.
	virtual void OnRegisterTopics( ITopics * a_pTopics )
	{
		assert( m_pTopics == NULL );
		m_pTopics = a_pTopics;
		m_TopicId = StringUtil::Format( "sensor-%s", GetSensorName() );
		m_pTopics->RegisterTopic( m_TopicId, GetSensorDataType().GetName(), 
			DELEGATE( ISensor, OnSubscriber, const ITopics::SubInfo &, this ) );
	}

	//! This is invoked to de-register this sensor from the topic system
	virtual void OnUnregisterTopics( ITopics * a_pTopics )
	{
		assert( m_pTopics == a_pTopics );
		a_pTopics->UnregisterTopic( m_TopicId );
		m_pTopics = NULL;
	}

	//! Subscribe to this sensor, any incoming data should be sent to the given delegate. 
	void Subscribe( Delegate<IData *> a_Subscriber )
	{
		bool bStart = (m_Subscribers.size() + m_TopicSubscribers) == 0;
		m_Subscribers.push_back(a_Subscriber);

		if ( bStart )
			OnStart();
	}

	//! Un-subscribe from this sensor, you pass the this pointer of the object that the delegate was initialized with..
	bool Unsubscribe( void * obj )
	{
		for (SubcriberList::iterator iSub = m_Subscribers.begin();
			iSub != m_Subscribers.end(); )
		{
			if ((*iSub).IsObject(obj))
				m_Subscribers.erase(iSub++);
			else
				++iSub;
		}

		if ( (m_Subscribers.size() + m_TopicSubscribers) == 0 )
			OnStop();

		return true;
	}

protected:

	//! Types
	typedef std::list< Delegate<IData *> > SubcriberList;

	//! Data
	SubcriberList		m_Subscribers;
	ITopics *			m_pTopics;
	std::string			m_TopicId;
	unsigned int		m_TopicSubscribers;

	void OnSubscriber( const ITopics::SubInfo & a_Sub )
	{
		if ( a_Sub.m_Subscribed )
		{
			bool bStart = (m_Subscribers.size() + m_TopicSubscribers) == 0;
			m_TopicSubscribers += 1;

			if ( bStart )
				OnStart();
		}
		else
		{
			m_TopicSubscribers -= 1;

			if ( (m_Subscribers.size() + m_TopicSubscribers) == 0 )
				OnStop();
		}
	}

	//! Send data to all subscribers of this sensor, note this function takes ownership
	//! of the IData object and will delete it once it's done processing with all sensors.
	void SendData( IData * a_Data )
	{
		if ( m_TopicSubscribers > 0 )
		{
			std::string data;
			if (a_Data->ToBinary(data))
			{
				// TODO: need to support binary data..
				m_pTopics->Publish(m_TopicId, StringUtil::EncodeBase64(data));
			}
		}

		if ( m_Subscribers.begin() != m_Subscribers.end() )
		{
			for(SubcriberList::iterator iSub = m_Subscribers.begin();
				iSub != m_Subscribers.end(); ++iSub )
			{
				(*iSub)( a_Data );
			}
		}

		// TODO: more than likely, we may want to use a shared pointer or reference counting system
		// so subscribers can hang onto the data for a while.
		delete a_Data;
		a_Data = NULL;
	}
};

#endif
