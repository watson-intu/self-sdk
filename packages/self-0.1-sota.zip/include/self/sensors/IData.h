/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_IDATA_H
#define SELF_IDATA_H

#include "utils/RTTI.h"
#include "SelfLib.h"

//! This is the base class for any type of data sent by a sensor
class SELF_API IData
{
public:
	RTTI_DECL();

	virtual ~IData()
	{}

	virtual bool ToBinary( std::string & a_Output )
	{
		return false;
	}
};

#endif
