/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_NETWORK_H
#define SELF_NETWORK_H

#include "SelfInstance.h"
#include "ISensor.h"
#include "HealthData.h"

#include "utils/TimerPool.h"
#include "utils/Time.h"

#include "SelfLib.h"

//! Base class for a Network sensor class
class SELF_API Network : public ISensor
{
public:
    RTTI_DECL();

    Network( ) : m_NetworkCheckInterval( 20 )
    {}

    //! ISerializable interface
    virtual void Serialize(Json::Value & json);
    virtual void Deserialize(const Json::Value & json);

    //! ISensor interface
    virtual const char * GetSensorName()
    {
        return "Network";
    }
    virtual RTTI & GetSensorDataType()
    {
        return HealthData::GetStaticRTTI();
    }

    virtual bool OnStart();
    virtual bool OnStop();
    virtual void OnPause();
    virtual void OnResume();

protected:
    //! Data
    std::vector<std::string>    m_Addresses;
    std::string                 m_RemoteIP;
    int                         m_NetworkCheckInterval;
    TimerPool::ITimer::SP       m_NetworkPingTimer;
	bool                        m_bProcessing;
	Time                        m_LastNetworkDown;
};

#endif	// SELF_NETWORK_H