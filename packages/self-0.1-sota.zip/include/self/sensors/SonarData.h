/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SELF_SONARDATA_H
#define SELF_SONARDATA_H

#include "SelfLib.h"

class SELF_API SonarData : public IData
{
public:
	RTTI_DECL();

	SonarData(float a_Distance)
		: m_fDistance(a_Distance)
	{}

	~SonarData()
	{}

	//!Accessors
	float GetDistance() const
	{
		return m_fDistance;
	}
private:
	//!Data
	float		m_fDistance;
};

#endif //SELF_SONARDATA_H
