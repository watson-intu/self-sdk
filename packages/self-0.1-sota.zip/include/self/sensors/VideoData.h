/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef VIDEO_DATA_H
#define VIDEO_DATA_H

#include <vector>
#include <cstring>
#include "IData.h"
#include "SelfLib.h"

class SELF_API VideoData : public IData
{
public:
	RTTI_DECL();

	VideoData(std::vector<unsigned char> a_BinaryData) : m_pBinaryData(NULL), m_BinaryLength(0)
	{
		m_pBinaryData = new unsigned char[a_BinaryData.size()];
		memcpy(m_pBinaryData, &a_BinaryData[0], a_BinaryData.size());
		m_BinaryLength = (int)a_BinaryData.size();
	}

	VideoData(const unsigned char * a_pBinaryData, int a_BinaryLength) : m_pBinaryData(NULL), m_BinaryLength(0)
	{
		m_pBinaryData = new unsigned char[a_BinaryLength];
		memcpy(m_pBinaryData, a_pBinaryData, a_BinaryLength);
		m_BinaryLength = a_BinaryLength;
	}
	~VideoData()
	{
		delete[] m_pBinaryData;
		m_pBinaryData = NULL;
	}

	//! IData interface
	virtual bool ToBinary( std::string & a_Output )
	{
		a_Output.assign( (char *)m_pBinaryData, m_BinaryLength );
		return true;
	}

	//!Accessors
	const unsigned char * GetBinaryData()
	{
		return m_pBinaryData;
	}

	int GetBinaryLength()
	{
		return m_BinaryLength;
	}


private:
	//!Data
	unsigned char * 	m_pBinaryData;
	int 				m_BinaryLength;
};


#endif //VIDEO_DATA_H
