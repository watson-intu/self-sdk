/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include <list>

#include "boost/shared_ptr.hpp"
#include "utils/Factory.h"
#include "utils/Delegate.h"
#include "utils/RTTI.h"
#include "ISensor.h"
#include "SelfLib.h"				// include last

//! Forward declare
class SelfInstance;
class ISensor;
class IData;
class TopicManager;

//! This manager initializes all sensor objects for the local environment. Various systems in Self can access
//! a sensor object and subscribe to receive data from a given sensor when it occurs.
class SELF_API SensorManager 
{
public:
	//! Types
	typedef std::list< boost::shared_ptr<ISensor> >	SensorList;
	typedef Delegate<IData *>		SensorDelegate;

	//! Construction
	SensorManager();
	//! Accessors
	const SensorList &		GetSensors() const;

	//! Initialize and start this sensor manager.
	bool					Start();
	//! Stop this sensor manager.
	bool					Stop();


	//! Add the sensor to this manager, it takes ownership of the object if accepted.
	bool					AddSensor( ISensor * a_pSensor );
	//! Remove a sensor from this manager.
	bool					RemoveSensor( ISensor * a_pSensor );
	//! Returns true if we have a sensor of the given type
	bool					HasSensor( const RTTI & sensorType ) const;
	//! Returns true if we have a sesnor that provides the given type of data
	bool					HasSensorData( const RTTI & dataType ) const;
	//! Finds all sensor types that generate the given type of data.
	void					FindSensors(const RTTI & dataType, SensorList & sensors) const;

	//! Pause all sensors of the given type
	void					PauseSensorType(const RTTI & dataType);
	//! Resume all sensors of the given type
	void					ResumeSensorType(const RTTI & dataType);


	template<typename T>
	T * FindSensor() const
	{
		for(SensorList::const_iterator iSensor = m_Sensors.begin(); iSensor != m_Sensors.end(); ++iSensor)
		{
			T * pSensor = DynamicCast<T>((*iSensor).get());
			if(pSensor != NULL)
				return pSensor;
		}

		return NULL;
	}

	template<typename T>
	T * GetSensor()
	{
		T * pSensor = FindSensor<T>();
		if ( pSensor == NULL )
		{
			pSensor = new T();
			if ( pSensor->OnStart() )
			{
				m_Sensors.push_back(  boost::shared_ptr<ISensor>(pSensor) );
				return pSensor;
			}

			delete pSensor;
			pSensor = NULL;
		}

		return pSensor;
	}

	template<typename T>
	bool RemoveSensorType()
	{
		T * pSensor = FindSensor<T>();
		if ( pSensor != NULL )
			return RemoveSensor( pSensor );

		return false;
	}

	void RemoveSensorsByDataType( const RTTI & a_DataType )
	{
		SensorList sensors;
		FindSensors( a_DataType, sensors );

		for( SensorList::iterator iSensor = sensors.begin(); iSensor != sensors.end(); ++iSensor )
			RemoveSensor( (*iSensor).get() );
	}

private:
	//! Data
	bool					m_bActive;
	SensorList				m_Sensors;		// list of active sensors
	TopicManager *			m_pTopicManager;
};

inline const SensorManager::SensorList & SensorManager::GetSensors() const
{
	return m_Sensors;
}

#endif
