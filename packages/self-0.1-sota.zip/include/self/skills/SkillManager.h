/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2001, 2014                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

#ifndef SKILL_MANAGER_H
#define SKILL_MANAGER_H

#include <string>
#include <map>
#include <set>

#include "SkillInstance.h"
#include "ISkill.h"

#include "utils/ParamsMap.h"
#include "utils/Delegate.h"
#include "utils/Factory.h"
#include "SelfLib.h"				// include last

//! Forward declare
class SelfInstance;
class ISkill;

//! This manager manages all ISkill instances including the saving and loading of skills from local storage.
class SELF_API SkillManager : public ISerializable
{
public:
	RTTI_DECL();

	//! Types
	typedef std::list<std::string>					SkillFiles;
	typedef boost::shared_ptr<ISkill>				ISkillSP;
	typedef std::map< std::string, ISkillSP >		SkillMap;
	typedef Factory< ISkill >						SkillFactory;

	typedef std::set< SkillInstance * >		SkillSet;

	//! Construction
	SkillManager();
	~SkillManager();

	//! ISerializable interface
	virtual void Serialize(Json::Value & json);
	virtual void Deserialize(const Json::Value & json);

	//! Accessors
	ISkill * FindSkill( const std::string & a_GUID ) const
	{
		SkillMap::const_iterator iSkill = m_SkillMap.find(a_GUID);
		if (iSkill != m_SkillMap.end())
			return iSkill->second.get();

		return NULL;
	}
	const SkillSet & GetActiveSkills() const
	{
		return m_ActiveSkills;
	}

	//! Use a skill by it's ID with the given parameters. The callback if provided
	//! will be invoked as the state changes for the skill. This object will be deleted
	//! automatically once the skill is completed after the final callback is made.
	SkillInstance * UseSkill( const std::string & a_skillGUID, const ParamsMap & a_Params,
		const Delegate<SkillInstance *> & a_Callback = Delegate<SkillInstance *>() )
	{
		return new SkillInstance( this, a_skillGUID, a_Params, a_Callback );
	}

	//! Abort all active skills
	bool AbortActiveSkills()
	{
		for( SkillSet::iterator iSkill = m_ActiveSkills.begin(); iSkill != m_ActiveSkills.end(); iSkill = m_ActiveSkills.begin() )
		{
			if (! (*iSkill)->Abort() )
				return false;		// failed to abort this skill
			
			delete *iSkill;
		}
		return true;
	}

	bool AbortActiveSkill(const std::string & a_Skill)
	{
		Log::Debug("SkillManager", "ATTEMPTING to Abort Active Skill: %s", a_Skill.c_str());
		for( SkillSet::iterator iSkill = m_ActiveSkills.begin(); iSkill != m_ActiveSkills.end(); ++iSkill )
		{
			Log::Debug("SkillManager", "Active Instance: %s", (*iSkill)->GetSkillGUID().c_str());
			if(!(*iSkill)->GetSkillGUID().compare(a_Skill))
			{
				Log::Debug("SkillManager", "Aborting Skill: %s", (*iSkill)->GetSkillGUID().c_str());
				if(! (*iSkill)->Abort() )
					return false;

				delete *iSkill;
				return true;
			}
		}
		return false;
	}

	//! Start this manager
	bool Start(const SkillFiles & a_SkillFiles);
	//! Stop this manager
	bool Stop();

	//! add a new skill into this manager. It will be saved into local storage and uploaded into remote storage.
	//! this manager takes ownership of this object and will delete it upon destruction.
	bool AddSkill( const ISkill::SP & a_spSkill, bool a_bAddRemote = true );
	//! delete a skill object by it's pointer.
	bool DeleteSkill( const ISkill::SP & a_spSkill );
	//! delete a skill by it's GUID
	bool DeleteSkill( const std::string & a_SkillGUID );

	void AddInstance( SkillInstance * a_pInstance );
	void RemoveInstance( SkillInstance * a_pInstance );

private:
	//! Data
	SkillMap		m_SkillMap;
	SkillSet		m_ActiveSkills;

	void OnSkillAdded( const Json::Value & );
    void OnSkillDeleted( const Json::Value & );
};


#endif
